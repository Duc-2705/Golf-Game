#pragma once

//Noi suy tuyen tinh
//0 <= scale <=1
float lerp(const float& current, const float& target, const float& scale);